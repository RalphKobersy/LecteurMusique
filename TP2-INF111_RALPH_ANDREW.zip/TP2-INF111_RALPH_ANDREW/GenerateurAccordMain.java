package musique;

/*
 * @author Ralph Kobersy et Andrew Kobersy 
 * @version H2020
 * 
 * Strategie
 * Cette classe permet de generer des accords grace a la classe GenerateurAccord 
 * et permet de jouer ces accords avec une duree predefinie 
 */
public class GenerateurAccordMain {
	
	//Constante pour la duree S
	public static final int DUREE=500;
	
	public static void main(String[] args) {
		
		 
		
		//D�claration des accord de type generateur accord
		GenerateurAccord gen= new GenerateurAccord();
		
	
		/*
		 * On obtient chacun des accords 
		 */
		Accord accordC= gen.obtenirAccord("C", DUREE);
		
		Accord accordDm= gen.obtenirAccord("Dm", DUREE);
		
		Accord accordEm= gen.obtenirAccord("Em", DUREE);
		
		Accord accordF= gen.obtenirAccord("F", DUREE);
		
		Accord accordG= gen.obtenirAccord("G", DUREE);
		
		Accord accordAm= gen.obtenirAccord("Am", DUREE);
		
		Accord accordB7= gen.obtenirAccord("B7", DUREE);
		
		
	
		//On joue les accords
		accordC.jouerAccord();
		//Permet de faire une pause entre chaque accord
		pause();
		
		accordDm.jouerAccord();
		
		pause(); 
		
		accordEm.jouerAccord();
		
		pause();
		
		accordF.jouerAccord();
		
		pause();
		
		accordG.jouerAccord();
		
		pause();
		
		accordAm.jouerAccord();
		
		pause();
		
		accordB7.jouerAccord();
		
		pause();
		

	}
	/*
	 * Methode qui permet d'effectuer une pause de 500 ms
	 * 
	 * @param aucun parametre 
	 * 
	 * @return aucune valeur de retour
	 * 
	 * @author Pierre Belisle
	 */
	public static void pause() {
		
		//Essaye de faire la pause 
		try {
			
			Thread.sleep(DUREE);	
		}
		
		//Si il y a une erreur on arrete les pauses
		catch(InterruptedException ex) {
			
			//On arrete si il y a un probleme
			Thread.currentThread().interrupt();
		}
		
	}
}
