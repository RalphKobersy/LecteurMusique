package musique;

import javax.swing.JOptionPane;

/*
 * @author Ralph Kobersy et Andrew Kobersy 
 * @version H2020
 * 
 * Strategie 
 * Cette classe permet d'afficher une menu graphique et offre a l'utilisateur 
 * 3 choix pour naviguer dans le menu. L'utilisateur doit d'abord selectionner
 * un fichier 
 */
public class TestChansonMain {
	
	public static void main(String[] args) {
		
		//Variable qui va permettre de quitter le menu de chanson
        boolean quitterMenuChanson=false;      
        
		//On initialise la chanson pour recevoir la chanson selectionne
		//par le fichier
		PieceMusicale chanson=null;
		
		//Tableau String qui contient les choix du menu chanson
		String[] optionMenuChanson= {Constantes.PREMIER_CHOIX
									,Constantes.DEUXIEME_CHOIX		
									,Constantes.TROISIEME_CHOIX};
		
		
		
        //Tant que l'utilsateur n'a pas quitter 
		while(!quitterMenuChanson) {
			
			//Permet d'enregistrer le choix de l'utilisateur 
			String choixDuMenuChanson = (String)JOptionPane.showInputDialog(null
					,"Veuillez choisir svp:"
					,"Menu de chanson"
					,JOptionPane.QUESTION_MESSAGE
					,null
					,optionMenuChanson
					,optionMenuChanson[2]);

				
			//Si l'utilisateur prend le premier choix 
				if(choixDuMenuChanson == Constantes.PREMIER_CHOIX) {
					
					//Permet d'obtenir la chanson 
					chanson=Fichier.obtenirChanson();
					
					//Permet de jouer la piece musicale
					chanson.jouerPieceMusicale();
					
					//Permet d'afficher les accords
					System.out.println(chanson.toString());
			
				}
				//Sinon si l'utilisateur choisi le deuxieme choix
				else if(choixDuMenuChanson == Constantes.DEUXIEME_CHOIX) {
					
					//Si l'utilisateur n'a pas jouer de chanson
					 if(chanson == null) {
						 
						 //Permet d'afficher un message d'erreur 
						 JOptionPane.showMessageDialog(null
								 					,Constantes.MESSAGE_ERREUR);
					 }
					 //Sinon 
					 else {
						 
						 //On joue la chanson
						 chanson.jouerPieceMusicale();
						 
						 //On affiche les accords 
						 System.out.println(chanson.toString());
						 
					 }
					
					
					
				}
				//Sinon 
				else {
						
						//Si on quitte la chanson 
						quitterMenuChanson= true;
						
						//On affiche le message de fin 
						JOptionPane.showMessageDialog(null
												,Constantes.MESSAGE_QUITTER);
						
					
				}

		}

	}


}
