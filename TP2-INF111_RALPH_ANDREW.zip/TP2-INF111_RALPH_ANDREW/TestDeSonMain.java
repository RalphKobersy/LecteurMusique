package musique;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

/*
 * Cette classe permet de tester les notes. Elle joue quelques notes 
 * grace a la methode jouer.
 */
public class TestDeSonMain {
	
	//On declare une variable ligne de type SourceDtaLine qui est static
	static SourceDataLine ligne;
	
	//Debut du main
	public static void main(String[]args) {
		
		//On instancie un son
		AudioFormat audioFmt= new AudioFormat(20500,16,1,true,true);
		
		/*/
		 * Essaye et lance une erreur si la ligne audio n'ouvre pas
		 */
		try {
			
			ligne=AudioSystem.getSourceDataLine(audioFmt);
			ligne.open(audioFmt);
			
			
		} catch(LineUnavailableException lue) {
			
			System.out.println("#Erreur: impossible de trouver une ligne"
								+ "de sortie audio au format :");
			
			System.out.println("#	"+ audioFmt);
			
			System.exit(1);
		}
		/*/
		 * Demarrage de production du son dans un thread.
		 */
		Thread t= new Thread(new Runnable() {
			
			@Override
			public void run() {
				
			
				//Demarre la production de son
				 ligne.start();
				 
				 //Joue la gamme de do majeure a une intensite de 
				 //30% pendant une demie seconde. Le 4 signifie 
				 //la gamme au centre du piano. C3 est plus grave et 
				 //C5 est plus aigu.
				 jouer(ligne,"C4",.3,500);
				 jouer(ligne,"D4",.3,500);
				 jouer(ligne,"E4",.3,500);
				 jouer(ligne,"F4",.3,500);
				 jouer(ligne,"G4",.3,500);
				 jouer(ligne,"A4",.3,500);
				 jouer(ligne,"B4",.3,500);
				 jouer(ligne,"C4",.3,1000);
			}
	});
		
		//On commence le thread 
		t.start();
		

	}
	/*
	 * Methode qui permet de jouer une note 
	 * 
	 * @param ligne qui est une SourceDataLine (un son audio)
	 * 
	 * @param note qui est la note 
	 * 
	 * @param intensite qui est l'intensite du son
	 * 
	 * @param duree qui est correspond a la dureee du son produit
	 */
	public static void jouer(SourceDataLine ligne,String note
			,double intensite
			,double duree) {
		
		//On cree une nouvelle note 
		Note n=new Note(note,duree);
		
		//On joue la note creer 
		n.jouer(ligne,intensite);


	}
	
	
}


	
