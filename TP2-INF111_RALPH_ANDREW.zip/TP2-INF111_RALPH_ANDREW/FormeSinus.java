package musique;

/*
 * La classe FormeSinus est une classe enfant de la classe parent FormeOnde
 */
public class FormeSinus extends FormeOnde {
	
	/*
	 * Methode qui permet de calculer une frequence 
	 * 
	 * @param i de type integer 
	 * 
	 * @return on retourne un frequence
	 */
	public double echantillon(int i) {
		 
		//On calcule la periode
		double periode=valeurPeriode();
		
		//On calcul la valeur de r
		double r=valeurR(i);
		
		//Si la valeur de r est plus petit que 0
		if(r<0) {
			
			//On incremente la valeur de r avec la periode
			r+=periode;
		}
		
		//On retourne la frequence calculee
		return Math.sin(2*(Math.PI)*getFrequence()*r);
				
	}
	/*
	 * Constructeur par copie d'attributs
	 * 
	 * @param frequence
	 * 
	 * @param frequenceEchantillonnage
	 */
	public FormeSinus(double frequence,double frequenceEchantillonnage) {
		
		//On utilise le constructeur par copie d'attribut de la classe parent
		super(frequence,frequenceEchantillonnage);
	}


}
