package musique;

import java.util.Vector;


/*
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020
 * 
 * Strategie 
 * Cette classe a plusieurs constructeurs et des methodes qui permettre de jouer
 * plusieurs accords pour creer une piece musicale 
 */
public class PieceMusicale {
	
	/*
	 * Attribut privee de la classe PieceMusicale
	 */
	private String nomPieceMusicale;
	private double rythme;
	private Vector<Accord> tableauAccord;
	
	/*
	 * Constructeur par copie d'attribut
	 * 
	 * @param rythme de type double
	 * 
	 * @param nomPieceMusicale de type String
	 */
	public PieceMusicale(String nomPieceMusicale, double rythme) {
		
		//On copie le nom de la piece musicale dans l'attribut de la classe
		this.nomPieceMusicale=nomPieceMusicale;
		
		//On copie le rythme dans l'attribut de la classe
		this.rythme=rythme;
		
		//On initialise la collection d'accord
		tableauAccord= new Vector<Accord>();
		
	}

	/*
	 * Methode qui ajoute un accord a la collection privee
	 * 
	 * @param accordMusique qui est un accord de musique 
	 * 
	 * @return aucun return
	 */
	public void ajoutAccord(Accord accordMusique) {
		
		tableauAccord.add(accordMusique);
	}
	
	
	/*
	 * Methode de debogage 
	 * 
	 * @param aucun parametre 
	 * 
	 * @return pieceMusicale valeur de type String
	 */
	public String toString() {
		
		//Valeur de retour
		String pieceMusicale="";
		
		//Accord qui fait parti de la colleciton 
		Accord accordLu;
		
		//Compteur de ligne 
		int compteurAccord=0;
		
		//Boucle qui parcourt la collection d'accord 
		for(int i=0;i<tableauAccord.size();++i) {
			
			//Permet d'obtenir l'accord selon la position
			accordLu=tableauAccord.get(i);
			
			//Appel a la fonction toString de la classe Accord
			accordLu.toString();
			
			//Si il y a plus que 4 accords
			if(compteurAccord>=4) {
				
				//On rajoute un saut de ligne 
				pieceMusicale+= "\n";
				
				//On remet le compteur d'accord a 0
				compteurAccord=0;
				
			}
			
			//On ajoute la chaine de caractere a la piece musicale qui 
			//correspond a la valeur de retour
			pieceMusicale+= accordLu;
			
			//On incremente le compteur des accords 
			compteurAccord++;
		}
		
		//On retourne la chaine de caractere
		return pieceMusicale;
	}
	
	/*/
	 * Methode qui permet de jouer chaque accord d'une piece musicale et
	 * 
	 * effectue une pause entre chaque accord.
	 * 
	 * @param no param
	 * 
	 * @return aucun return 
	 */
	public void jouerPieceMusicale() {
		
		//Parcourt la collection d'accord 
		for(int i=0;i<tableauAccord.size();i++) {
			
			//Rajoute les accords dans la collection
			tableauAccord.get(i).jouerAccord();
			
			//On obtient la duree de la pause selon l'accord 
			pause((int)tableauAccord.get(i).getNote().get(0).getDuree());
			
		}
	}
	/*
	 * Permet de pauser l'application pour donner du temps a un autre processus
	 *  
	 * dans un univers multitaches.
	 * 
	 * @param duree Le temps de la pause
	 * 
	 * @return aucun retour
	 * 
	 * @author Pierre Belisle
	 */
	private void pause(double duree) {
		
		//On essaye d'effectuer la pause
		try {
			
			//On effectue la pause 
			Thread.sleep((long) duree);
		
		//Si il y a un probleme on montre la trace 
		}catch(InterruptedException e) {
			
			//Affiche la trace du programme 
			e.printStackTrace();
			
		}
	}
	
}
