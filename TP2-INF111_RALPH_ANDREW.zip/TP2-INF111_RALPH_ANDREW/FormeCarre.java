package musique;

/*
 * La classe FormeCarre est une classe enfant de la classe parent FormeOnde
 * Elle permet de generer un frequence grace a une forme d'onde carre
 */
public class FormeCarre extends FormeOnde {

	/*
	 * Methode qui permet de calculer une frequence
	 * 
	 * @param i de type integer
	 * 
	 * @return valeurRetour de type double
	 */
	public double echantillon(int i) {

		
		//La valeur qui sera retourne
		double valeurRetour;

		//On calcule la periode
		double periode = valeurPeriode();

		//On calcule la valeur de r
		double r = valeurR(i);

		//Si r est plus petit que 0
		if (r < 0) {
			
			//On incremente la valeur de r avec la periode 
			r += periode;
		}

		//Si r est plus petit que la moitie de la periode 
		if (r < (periode / 2)) {
			
			//On retient 1 dans la valeur de retour
			valeurRetour = 1;
		
		}
		//Sinon 
		else {
			
			//On retient -1 dans la valeur de retour
			valeurRetour = -1;
		}
		
		//On retourne la valeur de retour
		return valeurRetour;
	}

	/*
	 * Constructeur par copie d'attributs
	 * 
	 * @param frequence
	 * 
	 * @param frequenceEchantillonnage
	 * 
	 * @return aucune valeur de retour
	 */
	public FormeCarre(double frequence, double frequenceEchantillonnage) {
		
		//On utilise le constructeur par copie d'attribut de la classe parent
		super(frequence, frequenceEchantillonnage);
	}

}
