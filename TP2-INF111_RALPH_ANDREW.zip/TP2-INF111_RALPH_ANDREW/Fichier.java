package musique;

/*
 * @author Ralph Kobersy et Andrew Kobersy 
 * @version H2020
 * 
 * 	Strategie
 * Voici la classe Fichier, cette classe comporte seulement une seule methode 
 * qui permet d'obtenir un fichier texte et de lire les accords et de faire 
 * jouer les accords qui sont dans le fichier obtenu.
 */

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileSystemView;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;


public class Fichier {
	
	/*
	 * Methode qui permet d'obtenir un fichier texte et de le lire et de le 
	 * jouer par la suite 
	 * @param aucun parametre 
	 * @return aucune valeur de retour 
	 * 
	 * Le code pour obtenir un fichier texte a ete recupere de ce site :
	 * https://mkyong.com/swing/java-swing-jfilechooser-example/
	 * 
	 * MIT License

	Copyright (c) 2020 Mkyong.com

	Permission is hereby granted, free of charge, to any person obtaining a copy
	of this software and associated documentation files (the �Software�), to deal
	in the Software without restriction, including without limitation the rights
	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
	copies of the Software, and to permit persons to whom the Software is
	furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in all
	copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED �AS IS�, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
	SOFTWARE.
	 */
	
	/*
	 * Methode qui permet d'obtenir un fichier texte et de faire jouer 
	 * 
	 * le contenu de ce fichier 
	 * 
	 * @param aucun parametre
	 * 
	 * @return aucune valeur de retour
	 */
	public static PieceMusicale obtenirChanson() {
		
		//On initialise un accord
		Accord accordGenere;
		
		//On initialise la chanson de type PieceMusicale avec null
		PieceMusicale chanson = null;
		
		//Declaration du fichier a selectionner
		File fichierSelectionner;
		
		//Permet de choisir un fichier selon le repertoire
		JFileChooser fileChooser = new JFileChooser(FileSystemView
													.getFileSystemView()
													.getHomeDirectory());
		
		//Ouvre une fenetre d'affichage
		int valeurRetour =fileChooser.showOpenDialog(null);
		
		//Si l'utilisateur a fais son choix
		if (valeurRetour == JFileChooser.APPROVE_OPTION) {
			
			//Retient le fichier choisi par l'utilsateur
			 fichierSelectionner = fileChooser.getSelectedFile();
			
			 //Affiche le repertoire du fichier
			//System.out.println(fichierSelectionner.getAbsolutePath());
			
			try {
				
				//Retient le fichier selectionner dans un Scanner pour 
				//le lire plus tard
				Scanner fichierAlire= new Scanner(fichierSelectionner);
				
				//Genere un accord
				GenerateurAccord gen= new GenerateurAccord();
				
				//Lecture du nom de l'accord
				String titrePieceMusicale = fichierAlire.nextLine();
				
				//Lecture du nombre de battement par minute
				int bpmPieceMusicale = fichierAlire.nextInt();
				
				//Declaration de la piece musicale avec le nom lu et le 
				//nombre de battement par minute
				chanson= new PieceMusicale(titrePieceMusicale
														,bpmPieceMusicale);
				
				//Tant que la lecture n'est pas terminer
				while(fichierAlire.hasNext()) {
					
					//On lit le nom de l'accord
					String accordAlire= fichierAlire.next();
					
					//On lit le temps de la duree
					double dureeAlire= fichierAlire.nextDouble();
					
					//On converti le duree en milliseconde
					dureeAlire= dureeAlire* (Constantes.MIN_EN_MS
														/bpmPieceMusicale);
					
					accordGenere =gen.obtenirAccord(accordAlire, dureeAlire);
					
					//On ajoute l'accord a la chanson
					chanson.ajoutAccord(accordGenere);
					
		
				}
			
	
				//Si le fichier n'est pas trouve
				}catch(FileNotFoundException e){
					
					//On retrace le parcours
					e.printStackTrace();
				
				
			}
			
			
			
		}
	
			
			//On retourne la chanson choisie
			return chanson;	
			
	
	}

}
