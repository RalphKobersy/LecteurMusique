package musique;

/*
 * @author Ralph Kobersy et Andrew Kobersy
 * @version H2020 
 * 
 *La classe FormeAleatoire est une classe enfant de la classe parent 
 *FormeOnde. Elle permet de generer une forme d'onde aleatoire.
 */

/*
 * La classe FormeAleatorie herite de la classe FormeOnde
 */
public class FormeAleatoire extends FormeOnde {
	
	/*
	 * Methode echantillon 
	 * 
	 * @param i de type integer
	 * 
	 * @return on retourne une valeur aleatoire entre 1 et -1
	 */
	public double echantillon(int i) {
		
		return (2*Math.random())-1;
		
	}
	/*
	 * Constructeur par defaut
	 * 
	 * @param aucun parametre 
	 * 
	 * @return aucune valeur de retour
	 */
	public FormeAleatoire() {
		
		//On utilise le constructeur par defaut de la classe parent
		super();
	}
}
